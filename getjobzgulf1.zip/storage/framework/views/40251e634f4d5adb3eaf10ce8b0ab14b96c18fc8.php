<?php $__env->startSection('content'); ?>
<!-- Header start -->
<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Header end --> 

<!-- Inner Page Title start -->
<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Xpress Resume')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Inner Page Title end -->

<div class="inner-page"> 
  <!-- About -->
  <div class="container">
        <div class="contact-wrap">
            <div class="title"> <span><?php echo e(__('Get XpressResume+ Get Noticed.')); ?></span>
                <h2><?php echo e(__('Better your chances of getting found & shortlisted')); ?></h2>
                
            </div>
           
        </div>

        <div class="row"> 
            <!-- Xpres  Resume -->

            <div class="contact-now">
                <div class="col-md-4 column">

                        <div class="paypackages"> 

                                <!---four-paln-->
                              
                                <div class="four-plan">
                              
                                  
                              
                                  <div class="row"> <?php $__currentLoopData = $serviceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($services->service_for == "xpress_resume"): ?>
                              
                                    
                              
                                      <ul class="boxes">
                              
                                        <li class="icon"><i class="fa fa-paper-plane" aria-hidden="true"></i></li>
                              
                                        <li class="plan-name"><?php echo e($services->service_title); ?></li>
                              
                                        <li>
                              
                                          <div class="main-plan">
                              
                                            
                              
                                            <div class="plan-price1-2"><span>$</span><?php echo e($services->service_price); ?></div>
                            
                                            <div class="service_desc"><?php echo e($services->service_description); ?></div>
                              
                                            <div class="clearfix"></div>
                              
                                          </div>
                              
                                        </li>
                              
                                        
                              
                                        <?php if((bool)$siteSetting->is_paypal_active): ?>
                              
                                        <li class="order paypal"><a href="<?php echo e(route('order.package', $services->id)); ?>"><i class="fa fa-cc-paypal" aria-hidden="true"></i> <?php echo e(__('pay with paypal')); ?></a></li>
                              
                                        <?php endif; ?>
                              
                                        <?php if((bool)$siteSetting->is_stripe_active): ?>
                              
                                        <li class="order"><a href="<?php echo e(route('stripe.order.form', [$services->id, 'new'])); ?>"><i class="fa fa-cc-stripe" aria-hidden="true"></i> <?php echo e(__('pay with stripe')); ?></a></li>
                              
                                        <?php endif; ?>
                              
                                      </ul>
                              
                                    
                                     <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
                              
                                </div>
                              
                                <!---end four-paln--> 
                              
                              </div>



                        
                </div>
                <!-- Why Xpress Resume-->
                <div class="col-md-8 column">
                       <div class="why_resume">
                            <h2 class="why_resume_title"><?php echo e(__('Why XpressResume')); ?></h2>
                            <ul class="why_resume_content">
                                    <li>Better your chances of getting found when a recruiter searches for a profile like yours<br></li>
                                    <li>It’s upfront when a recruiter takes a look at a large set of shortlisted resumes</li>
                                    <li>Your profile is promoted as the most closely matched jobseeker to the search criteria used by recruiters</li>
                                    <li>With XpressResume+ your profile is showcased as an active jobseeker, who is keenly looking for a job</li>
                                    <li>With XpressResume+ you stand out from the crowd, thus increasing your chances of getting shortlisted</li>
                                </ul>
                       </div>

                       <div class="why_resume" style="margin: 10px 0 0 0;">
                            <h2 class="why_resume_title"><?php echo e(__('How XPRESSResume+ works?')); ?></h2>
                       <p class="service_desc"><?php echo e(__('Once you subscribe to XPRESSResume+ you’ll get an order confirmation. Within 2 working days, you’ll get a mail from us asking for your latest resume. Once you upload your resume, you would be promoted as an active job seeker in the Monster database. Your resume will be listed at the top of search results, thus boosting your chanc es of getting shortlisted. We not only list your resume at the top but showcase your designation, education & experience, skills, industry, function and role you are in so that it grabs the attention of a recruiter.')); ?></p>
                       </div>
                   
                </div>
                
               

            </div>
        </div>
    </div>
</div>

  
  

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>