<div class="section">
	<div class="container">

		<div class="topsearchwrap">
				
				<div class="srchbx">				
				<!--Categories start-->
				<h4><?php echo e(__('Browse By Functional Area')); ?></h4>
				<div class="srchint">
				<ul class="row catelist">
					<?php if(isset($topFunctionalAreaIds) && count($topFunctionalAreaIds)): ?> <?php $__currentLoopData = $topFunctionalAreaIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $functional_area_id_num_jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					$functionalArea = App\ FunctionalArea::where( 'functional_area_id', '=', $functional_area_id_num_jobs->functional_area_id )->lang()->active()->first();
					?> <?php if(null !== $functionalArea): ?>
					
					<li class="col-md-4 col-sm-6"><a href="<?php echo e(route('job.list', ['functional_area_id[]'=>$functionalArea->functional_area_id])); ?>" title="<?php echo e($functionalArea->functional_area); ?>"><?php echo e($functionalArea->functional_area); ?> <span>(<?php echo e($functional_area_id_num_jobs->num_jobs); ?>)</span></a>
					</li>
					
					<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
				</ul>
				<!--Categories end-->
				</div>
				</div>
				
				<div class="srchbx">
				<!--Cities start-->
				<h4><?php echo e(__('Browse By Cities')); ?></h4>
				<div class="srchint">
				<ul class="row catelist">

					<?php if(isset($topCityIds) && count($topCityIds)): ?> <?php $__currentLoopData = $topCityIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city_id_num_jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<?php

					$city = App\ City::getCityById( $city_id_num_jobs->city_id );
					
					?> <?php if(null !== $city): ?>
					
					<li class="col-md-3 col-sm-4 col-xs-6"><a href="<?php echo e(route('job.list', ['city_id[]'=>$city->city_id])); ?>" title="<?php echo e($city->city); ?>"><?php echo e($city->city); ?> <span>(<?php echo e($city_id_num_jobs->num_jobs); ?>)</span></a>
					</li>
					
					<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
				</ul>
				<!--Cities end-->
				</div>
				</div>

				
				<div class="srchbx">
				<!--Categories start-->
				<h4><?php echo e(__('Browse By Industries')); ?></h4>
				<div class="srchint">
				<ul class="row catelist">					
					<?php if(isset($topIndustryIds) && count($topIndustryIds)): ?> <?php $__currentLoopData = $topIndustryIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry_id => $num_jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<?php

					$industry = App\ Industry::where( 'industry_id', '=', $industry_id )->lang()->active()->first();

					?> <?php if(null !== $industry): ?>

					<li class="col-md-4 col-sm-6"><a href="<?php echo e(route('job.list', ['industry_id[]'=>$industry->industry_id])); ?>" title="<?php echo e($industry->industry); ?>"><?php echo e($industry->industry); ?> <span>(<?php echo e($num_jobs); ?>)</span></a>
					</li>


					<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>

				</ul>
				<!--Categories end-->
				</div>
				</div>
                
				<div class="srchbx">
				<!--Categories start-->
				<h4><?php echo e(__('Browse By Skills')); ?></h4>
				<div class="srchint">
				<ul class="row catelist">					
					<?php if(isset($topSkillsIds) && count($topSkillsIds)): ?> <?php $__currentLoopData = $topSkillsIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_skill_id => $num_jobs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<?php
                   
					$skill = App\ JobSkill::where( 'job_skill_id', '=', $job_skill_id )->lang()->active()->first();
                    //$skill = App\ JobSkill::getUsingSkills( $num_jobs->job_skill_id );
					?> <?php if(null !== $skill): ?>

					<li class="col-md-4 col-sm-6"><a href="<?php echo e(route('job.list', ['job_skill_id[]'=>$skill->job_skill_id])); ?>" title="<?php echo e($skill->job_skill); ?>"><?php echo e($skill->job_skill); ?> <span>(<?php echo e($num_jobs); ?>)</span></a>
					</li>


					<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>

				</ul>
				
				<!--Categories end-->
				</div>
				</div>

	</div>
</div>
</div>