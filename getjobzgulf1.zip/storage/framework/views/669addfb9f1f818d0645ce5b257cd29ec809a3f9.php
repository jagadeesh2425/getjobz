<?php $__env->startSection('content'); ?> 

<!-- Header start --> 

<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<!-- Header end --> 



<!-- Inner Page Title start --> 

<?php echo $__env->make('includes.inner_page_title', ['page_title'=>__('Company Detail')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<!-- Inner Page Title end -->



<div class="listpgWraper">

  <div class="container"> 

    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

    <!-- Job Header start -->

    <div class="job-header">

      <div class="jobinfo">

        <div class="row">

          <div class="col-md-8 col-sm-8"> 

            <!-- Candidate Info -->

            <div class="candidateinfo">

              <div class="userPic"><a href="<?php echo e(route('company.detail',$company->slug)); ?>"><?php echo e($company->printCompanyImage()); ?></a></div>

              <div class="title"><?php echo e($company->name); ?></div>

              <div class="desi"><?php echo e($company->getIndustry('industry')); ?></div>

              <div class="loctext"><i class="fa fa-history" aria-hidden="true"></i> <?php echo e(__('Member Since')); ?>, <?php echo e($company->created_at->format('M d, Y')); ?></div>

              <div class="loctext"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($company->location); ?></div>

              <div class="clearfix"></div>

            </div>

          </div>

          <div class="col-md-4 col-sm-4"> 

            <!-- Candidate Contact -->

            <div class="candidateinfo">

            <?php if(!empty($company->phone)): ?>

              <div class="loctext"><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:<?php echo e($company->phone); ?>"><?php echo e($company->phone); ?></a></div>

            <?php endif; ?>

            <?php if(!empty($company->email)): ?>

              <div class="loctext"><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php echo e($company->email); ?>"><?php echo e($company->email); ?></a></div>

            <?php endif; ?>

            <?php if(!empty($company->website)): ?>

              <div class="loctext"><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a></div>

            <?php endif; ?>  

              <div class="cadsocial"> <?php echo $company->getSocialNetworkHtml(); ?> </div>

            </div>

          </div>

        </div>

      </div>

      

      <!-- Buttons -->

      <div class="jobButtons"> <?php if(Auth::check() && Auth::user()->isFavouriteCompany($company->slug)): ?> <a href="<?php echo e(route('remove.from.favourite.company', $company->slug)); ?>" class="btn"><i class="fa fa-floppy-o" aria-hidden="true"></i> <?php echo e(__('Favourite Company')); ?> </a> <?php else: ?> <a href="<?php echo e(route('add.to.favourite.company', $company->slug)); ?>" class="btn"><i class="fa fa-floppy-o" aria-hidden="true"></i> <?php echo e(__('Add to Favourite')); ?></a> <?php endif; ?> <a href="<?php echo e(route('report.abuse.company', $company->slug)); ?>" class="btn report"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> <?php echo e(__('Report Abuse')); ?></a> <a href="#contact_company" class="btn"><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e(__('Send Message')); ?></a> </div>

    </div>

    

    <!-- Job Detail start -->

    <div class="row">

      <div class="col-md-8"> 

        <!-- About Employee start -->

        <div class="job-header">

          <div class="contentbox">

            <h3><?php echo e(__('About Company')); ?></h3>

            <p><?php echo $company->description; ?></p>

          </div>

        </div>

        

        <!-- Opening Jobs start -->

        <div class="relatedJobs">

          <h3><?php echo e(__('Job Openings')); ?></h3>

          <ul class="searchList">

            <?php if(isset($company->jobs) && count($company->jobs)): ?>

            <?php $__currentLoopData = $company->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

            <!--Job start-->

            <li>

              <div class="row">

                <div class="col-md-8 col-sm-8">

                  <div class="jobimg"><a href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>" title="<?php echo e($companyJob->title); ?>"> <?php echo e($company->printCompanyImage()); ?> </a></div>

                  <div class="jobinfo">

                    <h3><a href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>" title="<?php echo e($companyJob->title); ?>"><?php echo e($companyJob->title); ?></a></h3>

                    <div class="companyName"><a href="<?php echo e(route('company.detail', $company->slug)); ?>" title="<?php echo e($company->name); ?>"><?php echo e($company->name); ?></a></div>

                    <div class="location">

                      <label class="fulltime" title="<?php echo e($companyJob->getJobType('job_type')); ?>"><?php echo e($companyJob->getJobType('job_type')); ?></label>

                      <label class="partTime" title="<?php echo e($companyJob->getJobShift('job_shift')); ?>"><?php echo e($companyJob->getJobShift('job_shift')); ?></label>

                      - <span><?php echo e($companyJob->getCity('city')); ?></span></div>

                  </div>

                  <div class="clearfix"></div>

                </div>

                <div class="col-md-4 col-sm-4">

                  <div class="listbtn"><a href="<?php echo e(route('job.detail', [$companyJob->slug])); ?>"><?php echo e(__('View Detail')); ?></a></div>

                </div>

              </div>

              <p><?php echo e(str_limit(strip_tags($companyJob->description), 150, '...')); ?></p>

            </li>

            <!--Job end--> 

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?> 

            

            <!-- Job end -->

          </ul>

        </div>

      </div>

      <div class="col-md-4"> 

        <!-- Company Detail start -->

        <div class="job-header">

          <div class="jobdetail">

            <h3><?php echo e(__('Company Detail')); ?></h3>

            <ul class="jbdetail">

            	<li class="row">

                <div class="col-md-6 col-xs-6"><?php echo e(__('Is Email Verified')); ?></div>

                <div class="col-md-6 col-xs-6"><span><?php echo e(((bool)$company->verified)? 'Yes':'No'); ?></span></div>

              </li>

              <li class="row">

                <div class="col-md-6 col-xs-6"><?php echo e(__('Total Employees')); ?></div>

                <div class="col-md-6 col-xs-6"><span><?php echo e($company->no_of_employees); ?></span></div>

              </li>

              <li class="row">

                <div class="col-md-6 col-xs-6"><?php echo e(__('Established In')); ?></div>

                <div class="col-md-6 col-xs-6"><span><?php echo e($company->established_in); ?></span></div>

              </li>

              <li class="row">

                <div class="col-md-6 col-xs-6"><?php echo e(__('Current jobs')); ?></div>

                <div class="col-md-6 col-xs-6"><span><?php echo e($company->countNumJobs('company_id',$company->id)); ?></span></div>

              </li>

            </ul>

          </div>

        </div>

        

        <!-- Google Map start -->

        <div class="job-header">

          <div class="jobdetail"><?php echo $company->map; ?></div>

        </div>

        

        <!-- Contact Company start -->

        <div class="job-header">

          <div class="jobdetail">

            <h3 id="contact_company"><?php echo e(__('Contact Company')); ?></h3>

            <div id="alert_messages"></div>

            <?php

                        $from_name = $from_email = $from_phone = $subject = $message = $from_id = '';

                        if (Auth::check()) {

                            $from_name = Auth::user()->name;

                            $from_email = Auth::user()->email;

                            $from_phone = Auth::user()->phone;

                            $from_id = Auth::user()->id;

                        }

                        $from_name = old('name', $from_name);

                        $from_email = old('email', $from_email);

                        $from_phone = old('phone', $from_phone);

                        $subject = old('subject');

                        $message = old('message');

                        ?>

            <form method="post" id="send-company-message-form">

              <?php echo e(csrf_field()); ?>


              <input type="hidden" name="to_id" value="<?php echo e($company->id); ?>">

              <input type="hidden" name="from_id" value="<?php echo e($from_id); ?>">

              <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">

              <input type="hidden" name="company_name" value="<?php echo e($company->name); ?>">

              <div class="formpanel">

                <div class="formrow">

                  <input type="text" name="from_name" value="<?php echo e($from_name); ?>" class="form-control" placeholder="<?php echo e(__('Your Name')); ?>">

                </div>

                <div class="formrow">

                  <input type="text" name="from_email" value="<?php echo e($from_email); ?>" class="form-control" placeholder="<?php echo e(__('Your Email')); ?>">

                </div>

                <div class="formrow">

                  <input type="text" name="from_phone" value="<?php echo e($from_phone); ?>" class="form-control" placeholder="<?php echo e(__('Phone')); ?>">

                </div>

                <div class="formrow">

                  <input type="text" name="subject" value="<?php echo e($subject); ?>" class="form-control" placeholder="<?php echo e(__('Subject')); ?>">

                </div>

                <div class="formrow">

                  <textarea name="message" class="form-control" placeholder="Message"><?php echo e($message); ?></textarea>

                </div>

                <div class="formrow"><?php echo app('captcha')->display(); ?></div>

                <div class="formrow">

                <input type="button" class="btn" value="<?php echo e(__('Submit')); ?>" id="send_company_message">

                </div>

              </div>

            </form>

          </div>

        </div>

      </div>

    </div>

  </div>

</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>

<style type="text/css">

.formrow iframe {

	height: 78px;

}

</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?> 

<script type="text/javascript">

    $(document).ready(function () {

        $(document).on('click', '#send_company_message', function () {

            var postData = $('#send-company-message-form').serialize();

            $.ajax({

                type: 'POST',

                url: "<?php echo e(route('contact.company.message.send')); ?>",

                data: postData,

                //dataType: 'json',

                success: function (data)

                {

                    response = JSON.parse(data);

                    var res = response.success;

                    if (res == 'success')

                    {

                        var errorString = '<div role="alert" class="alert alert-success">' + response.message + '</div>';

                        $('#alert_messages').html(errorString);

                        $('#send-company-message-form').hide('slow');

                        $(document).scrollTo('.alert', 2000);

                    } else

                    {

                        var errorString = '<div class="alert alert-danger" role="alert"><ul>';

                        response = JSON.parse(data);

                        $.each(response, function (index, value)

                        {

                            errorString += '<li>' + value + '</li>';

                        });

                        errorString += '</ul></div>';

                        $('#alert_messages').html(errorString);

                        $(document).scrollTo('.alert', 2000);

                    }

                },

            });

        });

    });

</script> 

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>