<div class="header">
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-sm-3 col-xs-12"> <a href="<?php echo e(url('/')); ?>" class="logo"><img src="<?php echo e(asset('/')); ?>sitesetting_images/thumb/<?php echo e($siteSetting->site_logo); ?>" alt="<?php echo e($siteSetting->site_name); ?>" /></a>
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div class="clearfix"></div>
      </div>
      <div class="col-md-10 col-sm-12 col-xs-12">

        <!-- Nav start -->

        <div class="navbar navbar-default" role="navigation">
          <div class="navbar-collapse collapse" id="nav-main">
            <ul class="nav navbar-nav">
              <li class="<?php echo e(Request::url() == route('index') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e(__('Home')); ?></a> </li>
              <?php $__currentLoopData = $show_in_top_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $cmsContent = App\CmsContent::getContentBySlug($top_menu->page_slug); ?>
              <li class="<?php echo e(Request::url() == route('cms', $top_menu->page_slug) ? 'active' : ''); ?>"><a href="<?php echo e(route('cms', $top_menu->page_slug)); ?>"><i class="fa fa-briefcase" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e($cmsContent->page_title); ?></a> </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <li class="dropdown"><a href="#"><i class="fa fa-user" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e(__('Services')); ?> <span class="caret"></span></a>

                <!-- dropdown start -->

                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('xpress.resume')); ?>"><?php echo e(__('Xpress Resume')); ?></a> </li>
                  <li><a href="<?php echo e(route('resume.highlighter')); ?>"><?php echo e(__('Resume Highlighter')); ?></a> </li>
                  <li><a href="<?php echo e(route('resume.writing')); ?>"><?php echo e(__('Resume Writing')); ?></a> </li>
                  <li><a href="<?php echo e(route('special.packages')); ?>"><?php echo e(__('Special Packages')); ?></a> </li>
                </ul>

                <!-- dropdown end -->

              </li>


           <!--   <li class="mega">Menu<i class="fa fa-briefcase" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i>
               
                <div class="mega-menu">
                  <div class="inside-mega-menu">
                    <?php

                $industries = App\Industry::getUsingIndustries(5);
      
                ?>
      
                <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
                <p><a href="<?php echo e(route('job.list', ['industry_id[]'=>$industry->industry_id])); ?>" style="color:white;"><?php echo e($industry->industry); ?></a></p>
      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <div class="inside-mega-menu">
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                  </div>
                  <div class="inside-mega-menu">
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                  </div>
                  <div class="inside-mega-menu">
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                    <p>mega-menu</p>
                  </div>
                </div>
              </li> -->
              <li class="<?php echo e(Request::url() == route('contact.us') ? 'active' : ''); ?>"><a href="<?php echo e(route('contact.us')); ?>"><i class="fa fa-envelope" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e(__('Contact us')); ?></a> </li>
              
              <?php if(Auth::check()): ?>
              <li class="dropdown userbtn"><a href=""><?php echo e(Auth::user()->printUserImage()); ?></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a> </li>
                  <li><a href="<?php echo e(route('my.profile')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('My Profile')); ?></a> </li>
                  <li><a href="<?php echo e(route('view.public.profile', Auth::user()->id)); ?>"><i class="fa fa-eye" aria-hidden="true"></i> <?php echo e(__('View Public Profile')); ?></a> </li>
                  <li><a href="<?php echo e(route('my.job.applications')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('My Job Applications')); ?></a> </li>
                  <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-header').submit();"><i class="fa fa-sign-out" aria-hidden="true"></i> <?php echo e(__('Logout')); ?></a> </li>
                  <form id="logout-form-header" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                  </form>
                </ul>
              </li>
              <?php endif; ?> <?php if(Auth::guard('company')->check()): ?>
              <li class="postjob"><a href="<?php echo e(route('post.job')); ?>"><?php echo e(__('Post a job')); ?></a> </li>
              <li class="dropdown userbtn"><a href=""><?php echo e(Auth::guard('company')->user()->printCompanyImage()); ?></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('company.home')); ?>"><i class="fa fa-tachometer" aria-hidden="true"></i> <?php echo e(__('Dashboard')); ?></a> </li>
                  <li><a href="<?php echo e(route('company.profile')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Company Profile')); ?></a></li>
                  <li><a href="<?php echo e(route('post.job')); ?>"><i class="fa fa-desktop" aria-hidden="true"></i> <?php echo e(__('Post Job')); ?></a></li>
                  <li><a href="<?php echo e(route('company.messages')); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo e(__('Company Messages')); ?></a></li>
                  <li><a href="<?php echo e(route('company.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-header1').submit();"><?php echo e(__('Logout')); ?></a> </li>
                  <form id="logout-form-header1" action="<?php echo e(route('company.logout')); ?>" method="POST" style="display: none;">
                    <?php echo e(csrf_field()); ?>

                  </form>
                </ul>
              </li>
              <?php endif; ?> <?php if(!Auth::user() && !Auth::guard('company')->user()): ?>
              <li class="dropdown"><a href="<?php echo e(route('login')); ?>"><i class="fa fa-user" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e(__('Candidate')); ?> <span class="caret"></span></a>

                <!-- dropdown start -->

                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign in')); ?></a> </li>
                  <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a> </li>
                  <li><a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password')); ?>?</a> </li>
                </ul>

                <!-- dropdown end -->

              </li>
              <li class="dropdown"><a href="<?php echo e(route('login')); ?>"><i class="fa fa-group" style="font-size:19px;padding-right: 5px;color: #18a7ff;"></i><?php echo e(__('Employer')); ?> <span class="caret"></span></a>

                <!-- dropdown start -->

                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('employer.login')); ?>"><?php echo e(__('Sign in')); ?></a> </li>
                  <li><a href="<?php echo e(route('employer.register')); ?>"><?php echo e(__('Register')); ?></a> </li>
                  <li><a href="<?php echo e(route('password.request')); ?>"><?php echo e(__('Forgot Password')); ?>?</a> </li>
                </ul>

                <!-- dropdown end -->

              </li>
              <?php endif; ?>
              <!-- <li class="dropdown userbtn"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/')); ?>images/lang.png" alt="" class="userimg" /></a>
                <ul class="dropdown-menu">
                  <?php $__currentLoopData = $siteLanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteLang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="javascript:;" onclick="event.preventDefault(); document.getElementById('locale-form-<?php echo e($siteLang->iso_code); ?>').submit();"><?php echo e($siteLang->native); ?></a>
                    <form id="locale-form-<?php echo e($siteLang->iso_code); ?>" action="<?php echo e(route('set.locale')); ?>" method="POST" style="display: none;">
                      <?php echo e(csrf_field()); ?>

                      <input type="hidden" name="locale" value="<?php echo e($siteLang->iso_code); ?>"/>
                      <input type="hidden" name="return_url" value="<?php echo e(url()->full()); ?>"/>
                      <input type="hidden" name="is_rtl" value="<?php echo e($siteLang->is_rtl); ?>"/>
                    </form>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li> -->
            </ul>

            <!-- Nav collapes end -->

          </div>
          <div class="clearfix"></div>
        </div>

        <!-- Nav end -->

      </div>
    </div>

    <!-- row end -->

  </div>

  <!-- Header container end -->

</div>
