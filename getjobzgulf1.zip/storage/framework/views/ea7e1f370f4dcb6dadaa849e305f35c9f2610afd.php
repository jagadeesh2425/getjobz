<?php
$lang = config('default_lang');
$direction = MiscHelper::getLangDirection($lang);
?>


<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper"> 
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content"> 
        <!-- BEGIN PAGE HEADER--> 
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li> <a href="<?php echo e(route('admin.home')); ?>">Home</a> <i class="fa fa-circle"></i> </li>        
                <li> <span>Edit Site Setting</span> </li>
            </ul>
        </div>
        <!-- END PAGE BAR --> 
        <!-- BEGIN PAGE TITLE-->
        <!--<h3 class="page-title">Edit User <small>Users</small> </h3>-->
        <!-- END PAGE TITLE--> 
        <!-- END PAGE HEADER-->
        <br />
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption font-red-sunglo"> <i class="icon-settings font-red-sunglo"></i> <span class="caption-subject bold uppercase">Site Setting Form</span> </div>
                    </div>

                    <div class="portlet-body form">          
                        <ul class="nav nav-tabs">              
                            <li class="active"> <a href="#site" data-toggle="tab" aria-expanded="false"> Site </a> </li>              
                            <li class=""> <a href="#email" data-toggle="tab" aria-expanded="false"> Email </a> </li>
                            <li class=""> <a href="#social" data-toggle="tab" aria-expanded="false"> Social Networks </a> </li>
                            <li class=""> <a href="#ads" data-toggle="tab" aria-expanded="false"> Manage Ads </a> </li>
                            <li class=""> <a href="#captcha" data-toggle="tab" aria-expanded="false"> Captcha </a> </li>
                            <!--<li class=""> <a href="#socialMediaLogin" data-toggle="tab" aria-expanded="false"> Social Media Login </a> </li>-->
                            <li class=""> <a href="#paymentGateways" data-toggle="tab" aria-expanded="false"> Payment Gateways </a> </li>              
                        </ul>

                        <?php echo Form::model($siteSetting, array('method' => 'put', 'route' => array('update.site.setting'), 'class' => 'form', 'files'=>true)); ?>

                        <div class="tab-content">              
                            <div class="tab-pane fade active in" id="site"> <?php echo $__env->make('admin.site_setting.forms.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
                            <div class="tab-pane fade" id="email"> <?php echo $__env->make('admin.site_setting.forms.siteEmailSetting_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
                            <div class="tab-pane fade" id="social"> <?php echo $__env->make('admin.site_setting.forms.siteSocialSetting_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
                            <div class="tab-pane fade" id="ads"> <?php echo $__env->make('admin.site_setting.forms.siteAds_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>

                            <div class="tab-pane fade" id="captcha"> <?php echo $__env->make('admin.site_setting.forms.captchaSetting_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
                            <div class="tab-pane fade" id="socialMediaLogin"> <?php echo $__env->make('admin.site_setting.forms.socialMediaLoginSetting_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
                            <div class="tab-pane fade" id="paymentGateways"> <?php echo $__env->make('admin.site_setting.forms.paymentGatewaysSetting_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>

                        </div>
                        <div class="form-actions">
                            <?php echo Form::button('Update <i class="fa fa-arrow-circle-right" aria-hidden="true"></i>', array('class'=>'btn btn-large btn-primary', 'type'=>'submit')); ?>

                        </div>
                        <?php echo Form::close(); ?>



                    </div>
                </div>
            </div>
        </div>
        <!-- END CONTENT BODY --> 
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('admin.shared.tinyMCE', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>