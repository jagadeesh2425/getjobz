<?php if($video): ?>
<div class="videowraper section">

  <div class="container">

    <!-- title start -->

    <div class="titleTop">

      <div class="subtitle"><?php echo e(__('Here You Can See')); ?></div>

      <h3><?php echo e(__('Watch Our')); ?> <span><?php echo e(__('Video')); ?></span></h3>

    </div>

    <!-- title end -->



    <p><?php echo e($video->video_text !== '' || $video->video_text !== null ? $video->video_text : ''); ?></p>

    <a href="<?php echo e($video->video_link); ?>" target="_blank"><i class="fa fa-play-circle-o" aria-hidden="true"></i></a> </div>

</div>
<?php endif; ?>
