<div class="searchwrap">

  <div class="container">

    <h3><span><?php echo e(__('Search Gulf Jobs.Find Yours Job Today.')); ?></span></h3>



    <?php if(Auth::guard('company')->check()): ?>

    <form action="<?php echo e(route('job.seeker.list')); ?>" method="get">

    <div class="searchbar row">

      <div class="col-md-<?php echo e(((bool)$siteSetting->country_specific_site)? 12:8); ?>">

        <input type="text"  name="search" value="<?php echo e(Request::get('search', '')); ?>" class="form-control" placeholder="<?php echo e(__('Enter Skills or Job Seeker Details')); ?>" />

      </div>

      <div class="col-md-4">

        <?php echo Form::select('functional_area_id[]', ['' => __('Select Functional Area')]+$functionalAreas, Request::get('functional_area_id', null), array('class'=>'form-control', 'id'=>'functional_area_id')); ?>


      </div>



      <?php if((bool)$siteSetting->country_specific_site): ?>

      <?php echo Form::hidden('country_id[]', Request::get('country_id[]', $siteSetting->default_country_id), array('id'=>'country_id')); ?>


      <?php else: ?>

      <div class="col-md-4">

      <?php echo Form::select('country_id[]', ['' => __('Select Country')]+$countries, Request::get('country_id', $siteSetting->default_country_id), array('class'=>'form-control', 'id'=>'country_id')); ?>


      </div>

      <?php endif; ?>



      <div class="col-md-3">

      <span id="state_dd">

      <?php echo Form::select('state_id[]', ['' => __('Select State')], Request::get('state_id', null), array('class'=>'form-control', 'id'=>'state_id')); ?>


      </span>

      </div>

      <div class="col-md-3">

      <span id="city_dd">

      <?php echo Form::select('city_id[]', ['' => __('Select City')], Request::get('city_id', null), array('class'=>'form-control', 'id'=>'city_id')); ?>


      </span>

      </div>

      <div class="col-md-2">

        <input type="submit" class="btn" value="<?php echo e(__('Search Job Seeker')); ?>">

      </div>

    </div>

    </form>

    <?php else: ?>

    <form action="<?php echo e(route('job.list')); ?>" method="get">

    <div class="searchbar row">

      <div class="col-md-<?php echo e(((bool)$siteSetting->country_specific_site)? 12:8); ?>">

        <input type="text"  name="search" value="<?php echo e(Request::get('search', '')); ?>" class="form-control" placeholder="<?php echo e(__('Enter Skills or job title')); ?>" />

      </div>

      <div class="col-md-4">

        <?php echo Form::select('functional_area_id[]', ['' => __('Select Functional Area')]+$functionalAreas, Request::get('functional_area_id', null), array('class'=>'form-control', 'id'=>'functional_area_id')); ?>


      </div>



      <?php if((bool)$siteSetting->country_specific_site): ?>

      <?php echo Form::hidden('country_id[]', Request::get('country_id[]', $siteSetting->default_country_id), array('id'=>'country_id')); ?>


      <?php else: ?>

      <div class="col-md-4">

      <?php echo Form::select('country_id[]', ['' => __('Select Country')]+$countries, Request::get('country_id', $siteSetting->default_country_id), array('class'=>'form-control', 'id'=>'country_id')); ?>


      </div>

      <?php endif; ?>



      <div class="col-md-3">

      <span id="state_dd">

      <?php echo Form::select('state_id[]', ['' => __('Select State')], Request::get('state_id', null), array('class'=>'form-control', 'id'=>'state_id')); ?>


      </span>

      </div>

      <div class="col-md-3">

      <span id="city_dd">

      <?php echo Form::select('city_id[]', ['' => __('Select City')], Request::get('city_id', null), array('class'=>'form-control', 'id'=>'city_id')); ?>


      </span>

      </div>

      <div class="col-md-2">

        <input type="submit" class="btn" value="<?php echo e(__('Search Job')); ?>">

      </div>

    </div>

    </form>

    <?php endif; ?>



    <!-- button start

    <div class="getstarted"><a href="<?php echo e(url('/')); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e(__('Get Started Now')); ?></a></div>

    button end -->



  </div>

</div>
