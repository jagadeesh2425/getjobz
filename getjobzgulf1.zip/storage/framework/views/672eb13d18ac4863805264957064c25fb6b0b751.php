<?php if((string)$siteSetting->facebook_address !== ''): ?>
<a href="<?php echo e($siteSetting->facebook_address); ?>" target="_blank"><i class="fa fa-facebook-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->google_plus_address !== ''): ?>
<a href="<?php echo e($siteSetting->google_plus_address); ?>" target="_blank"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->pinterest_address !== ''): ?>
<a href="<?php echo e($siteSetting->pinterest_address); ?>" target="_blank"><i class="fa fa-pinterest-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->twitter_address !== ''): ?>
<a href="<?php echo e($siteSetting->twitter_address); ?>" target="_blank"><i class="fa fa-twitter-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->instagram_address !== ''): ?>
<a href="<?php echo e($siteSetting->instagram_address); ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->linkedin_address !== ''): ?>
<a href="<?php echo e($siteSetting->linkedin_address); ?>" target="_blank"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->youtube_address !== ''): ?>
<a href="<?php echo e($siteSetting->youtube_address); ?>" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->tumblr_address !== ''): ?>
<a href="<?php echo e($siteSetting->tumblr_address); ?>" target="_blank"><i class="fa fa-tumblr-square" aria-hidden="true"></i></a>
<?php endif; ?>

<?php if((string)$siteSetting->flickr_address !== ''): ?>
<a href="<?php echo e($siteSetting->flickr_address); ?>" target="_blank"><i class="fa fa-flickr-square" aria-hidden="true"></i></a>
<?php endif; ?>