<?php if($video): ?>
<div class="videowraper section">
    <div class="container">
		
		<div class="row">
			<div class="col-md-6">
			
				<div class="embed-responsive embed-responsive-16by9">
              <iframe src="https://www.youtube.com/embed/FxiskmF16gU?rel=0&amp;showinfo=0" frameborder="0" allowfullscreen=""></iframe>
            </div>
			
			</div>
			<div class="col-md-6">
			
			 <!-- title start -->
        <div class="titleTop">
            <div class="subtitle">Here You Can See</div>
            <h3>Watch Our <span>Video</span></h3>
        </div>
        <!-- title end -->
        <p>Our partners make Milestone products more dynamic and integrations push the limits of what is possible. XProtect® software protects animals from known poachers and protects the city of Minneapolis.</p>
			
			</div>
		</div>
		
		
       
       </div>
</div>
<?php endif; ?>
